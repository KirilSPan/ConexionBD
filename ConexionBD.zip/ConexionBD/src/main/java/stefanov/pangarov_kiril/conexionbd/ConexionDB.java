/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package stefanov.pangarov_kiril.conexionbd;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

/**
 *
 * @author Kiril_SP
 */
public class ConexionDB {

    static final String DB_URI = "jdbc:mysql://localhost:3306/jcvd";
    static final String USER = "kiril";
    static final String PASS = "12345";

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        menu();

    }

    public static void menu() {
        try ( Scanner teclado = new Scanner(System.in)) {
            boolean salida = false;
            while (!salida) {
                System.out.println("Opciones:");
                System.out.println("1. Buscar Nombre");
                System.out.println("2. Lanzar Consulta");
                System.out.println("3. Nuevo Registro");
                System.out.println("4. Eliminar Registro");
                System.out.println("5. Salida");

                System.out.println("Enter your choice: ");
                int choice = teclado.nextInt();
                teclado.nextLine(); // Para no dejar un espacio en blanco

                switch (choice) {
                    case 1 -> {
                        System.out.println("Dime un nombre: ");
                        String nombre = teclado.nextLine();
                        System.out.println(buscarNombre(nombre));
                    }
                    case 2 -> {
                        System.out.println("Dime una consulta: ");
                        String consulta = teclado.nextLine();
                        System.out.println(lanzaConsulta(consulta));
                    }
                    case 3 -> {
                        System.out.println("Dime nuevo Registro: ");
                        System.out.println("Dime un nuevo Nombre: ");
                        String nuevoNombre = teclado.nextLine();
                        System.out.println("Dime un nuevo Genero: ");
                        String nuevoGenero = teclado.nextLine();
                        System.out.println("Dime una nueva Fecha de Lanzamiento: ");
                        String nuevaFecha = teclado.nextLine();
                        System.out.println("Dime una nueva Compañia: ");
                        String nuevaCompania = teclado.nextLine();
                        System.out.println("Dime un nuevo Precio: ");
                        float nuevoPrecio = teclado.nextFloat();
                        teclado.nextLine(); // Para no dejar un espacio en blanco
                        System.out.println(nuevoRegistro(nuevoNombre, nuevoGenero, nuevaFecha, nuevaCompania, nuevoPrecio));
                    }
                    case 4 -> {
                        System.out.println("Dime un nombre para eliminar: ");
                        String nombreEliminar = teclado.nextLine();
                        System.out.println(eliminarRegistro(nombreEliminar));
                    }
                    case 5 ->
                        salida = true;
                    default ->
                        System.out.println("Opción Invalida.");
                }
            }

        }
    }

    @SuppressWarnings("CallToPrintStackTrace")
    public static boolean buscarNombre(String nombreJ) {
        boolean salida = false;
        String QUERY = "select * from Videojuegos where Nombre like '" + nombreJ + "';";

        try ( Connection conn = DriverManager.getConnection(DB_URI, USER, PASS);  Statement stmt = conn.createStatement();  ResultSet rs = stmt.executeQuery(QUERY)) {

            while (rs.next()) {
                salida = nombreJ.equalsIgnoreCase(rs.getString("Nombre"));
            }
            stmt.close();
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return salida;
    }

    @SuppressWarnings("CallToPrintStackTrace")
    public static String lanzaConsulta(String queryJ) {
        String salida = "";

        try ( Connection conn = DriverManager.getConnection(DB_URI, USER, PASS);  Statement stmt = conn.createStatement();  ResultSet rs = stmt.executeQuery(queryJ)) {

            while (rs.next()) {

                salida += "ID: " + rs.getInt("id") + "\n";
                salida += ", Nombre: " + rs.getString("nombre") + "\n";
                salida += ", Genero: " + rs.getString("genero") + "\n";
                salida += ", Fecha de Lanzamiento: " + rs.getDate("fechaLanzamiento") + "\n";
                salida += ", Compañia: " + rs.getString("compañia") + "\n";
                salida += "y Precio: " + rs.getFloat("precio");

            }
            stmt.close();
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return salida;
    }

    @SuppressWarnings("CallToPrintStackTrace")
    public static boolean nuevoRegistro(String nombreJ, String generoJ, String fechaLanJ, String compañiaJ, float precioJ) {

        boolean salida = false;

        try ( Connection conn = DriverManager.getConnection(DB_URI, USER, PASS);  Statement stmt = conn.createStatement()) {

            Date fechaL = Date.valueOf(fechaLanJ);

            if (salida = true) {
                String queryN = "insert into videojuegos (Nombre, Genero, FechaLanzamiento, Compañia, Precio) values ('" + nombreJ + "', '"
                        + generoJ + "', '" + fechaL + "', '" + compañiaJ + "', " + precioJ + ");";

                stmt.executeUpdate(queryN);
                salida = stmt.isPoolable();
            } else {

                salida = false;
            }

            stmt.close();
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return salida;
    }

    @SuppressWarnings("CallToPrintStackTrace")
    public static boolean eliminarRegistro(String nombreJ) {
        boolean salida = false;
        String queryNE = "select nombre from videojuegos where nombre like '" + nombreJ + "';";
        String nombreC = null;

        try ( Connection conn = DriverManager.getConnection(DB_URI, USER, PASS);  Statement stmt = conn.createStatement();  ResultSet rs = stmt.executeQuery(queryNE)) {

            while (rs.next()) {

                nombreC = rs.getString("nombre");

            }

            if (nombreJ.equalsIgnoreCase(nombreC)) {
                String queryE = "delete from videojuegos where nombre like '" + nombreJ + "';";
                stmt.executeUpdate(queryE);

                salida = true;
            } else {
                salida = false;
            }

            stmt.close();
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return salida;
    }

}
